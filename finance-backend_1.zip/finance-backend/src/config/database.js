/**
 * Database Configuration
 * Uses SQLite via better-sqlite3 for zero-config local persistence.
 * Schema is created on first run — no migration tooling required for this scope.
 */

const Database = require("better-sqlite3");
const path = require("path");

const DB_PATH = path.join(__dirname, "../../finance.db");

let db;

function getDb() {
  if (!db) {
    db = new Database(DB_PATH);
    db.pragma("journal_mode = WAL");   // Write-Ahead Logging: better concurrency
    db.pragma("foreign_keys = ON");    // Enforce FK constraints
    initSchema(db);
  }
  return db;
}

function initSchema(db) {
  db.exec(`
    -- ─── Users ─────────────────────────────────────────────────────────────────
    CREATE TABLE IF NOT EXISTS users (
      id          INTEGER PRIMARY KEY AUTOINCREMENT,
      name        TEXT    NOT NULL,
      email       TEXT    NOT NULL UNIQUE COLLATE NOCASE,
      password    TEXT    NOT NULL,
      role        TEXT    NOT NULL DEFAULT 'viewer'
                          CHECK (role IN ('viewer', 'analyst', 'admin')),
      status      TEXT    NOT NULL DEFAULT 'active'
                          CHECK (status IN ('active', 'inactive')),
      created_at  TEXT    NOT NULL DEFAULT (datetime('now')),
      updated_at  TEXT    NOT NULL DEFAULT (datetime('now'))
    );

    -- ─── Financial Records ───────────────────────────────────────────────────
    CREATE TABLE IF NOT EXISTS financial_records (
      id          INTEGER PRIMARY KEY AUTOINCREMENT,
      amount      REAL    NOT NULL CHECK (amount > 0),
      type        TEXT    NOT NULL CHECK (type IN ('income', 'expense')),
      category    TEXT    NOT NULL,
      date        TEXT    NOT NULL,          -- ISO 8601 date string: YYYY-MM-DD
      notes       TEXT,
      is_deleted  INTEGER NOT NULL DEFAULT 0 CHECK (is_deleted IN (0, 1)),
      created_by  INTEGER NOT NULL REFERENCES users(id),
      updated_by  INTEGER          REFERENCES users(id),
      created_at  TEXT    NOT NULL DEFAULT (datetime('now')),
      updated_at  TEXT    NOT NULL DEFAULT (datetime('now'))
    );

    -- ─── Indexes ─────────────────────────────────────────────────────────────
    CREATE INDEX IF NOT EXISTS idx_records_type        ON financial_records(type);
    CREATE INDEX IF NOT EXISTS idx_records_category    ON financial_records(category);
    CREATE INDEX IF NOT EXISTS idx_records_date        ON financial_records(date);
    CREATE INDEX IF NOT EXISTS idx_records_is_deleted  ON financial_records(is_deleted);
  `);
}

module.exports = { getDb };
