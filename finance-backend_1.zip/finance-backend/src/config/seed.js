/**
 * Seed Script
 * Run once: node src/config/seed.js
 * Creates a default admin user and sample financial records for testing.
 */

const bcrypt = require("bcryptjs");
const { getDb } = require("./database");

async function seed() {
  const db = getDb();

  console.log("🌱 Seeding database...");

  // ── Users ──────────────────────────────────────────────────────────────────
  const users = [
    {
      name: "Alice Admin",
      email: "admin@finance.dev",
      password: "Admin@1234",
      role: "admin",
    },
    {
      name: "Ana Analyst",
      email: "analyst@finance.dev",
      password: "Analyst@1234",
      role: "analyst",
    },
    {
      name: "Victor Viewer",
      email: "viewer@finance.dev",
      password: "Viewer@1234",
      role: "viewer",
    },
  ];

  const insertUser = db.prepare(`
    INSERT OR IGNORE INTO users (name, email, password, role)
    VALUES (@name, @email, @password, @role)
  `);

  const createdUsers = {};
  for (const user of users) {
    const hash = bcrypt.hashSync(user.password, 10);
    insertUser.run({ ...user, password: hash });
    const row = db.prepare("SELECT id FROM users WHERE email = ?").get(user.email);
    createdUsers[user.role] = row.id;
    console.log(`  ✅ User seeded: ${user.email} (${user.role})`);
  }

  const adminId = createdUsers["admin"];

  // ── Financial Records ──────────────────────────────────────────────────────
  const records = [
    { amount: 5000,  type: "income",  category: "Salary",       date: "2025-01-05", notes: "Monthly salary" },
    { amount: 1200,  type: "expense", category: "Rent",          date: "2025-01-06", notes: "January rent" },
    { amount: 200,   type: "expense", category: "Utilities",     date: "2025-01-10", notes: "Electricity bill" },
    { amount: 800,   type: "income",  category: "Freelance",     date: "2025-01-15", notes: "Web design project" },
    { amount: 350,   type: "expense", category: "Groceries",     date: "2025-01-18", notes: null },
    { amount: 5000,  type: "income",  category: "Salary",        date: "2025-02-05", notes: "Monthly salary" },
    { amount: 1200,  type: "expense", category: "Rent",          date: "2025-02-06", notes: "February rent" },
    { amount: 150,   type: "expense", category: "Subscriptions", date: "2025-02-12", notes: "SaaS tools" },
    { amount: 1500,  type: "income",  category: "Freelance",     date: "2025-02-20", notes: "Mobile app work" },
    { amount: 300,   type: "expense", category: "Groceries",     date: "2025-02-22", notes: null },
    { amount: 5000,  type: "income",  category: "Salary",        date: "2025-03-05", notes: "Monthly salary" },
    { amount: 1200,  type: "expense", category: "Rent",          date: "2025-03-06", notes: "March rent" },
    { amount: 400,   type: "expense", category: "Dining",        date: "2025-03-14", notes: "Team dinner" },
    { amount: 2000,  type: "income",  category: "Investment",    date: "2025-03-28", notes: "Dividend payout" },
    { amount: 500,   type: "expense", category: "Travel",        date: "2025-03-30", notes: "Conference trip" },
  ];

  const insertRecord = db.prepare(`
    INSERT OR IGNORE INTO financial_records (amount, type, category, date, notes, created_by)
    VALUES (@amount, @type, @category, @date, @notes, @created_by)
  `);

  const seedMany = db.transaction((records) => {
    for (const r of records) {
      insertRecord.run({ ...r, created_by: adminId });
    }
  });

  seedMany(records);
  console.log(`  ✅ ${records.length} financial records seeded`);

  console.log("\n🎉 Seed complete!\n");
  console.log("Default credentials:");
  users.forEach((u) => console.log(`  ${u.role.padEnd(8)} → ${u.email} / ${u.password}`));
  console.log("");
}

seed().catch((err) => {
  console.error("Seed failed:", err);
  process.exit(1);
});
