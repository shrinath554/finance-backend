/**
 * Pagination Helper
 * Parses query params and returns LIMIT / OFFSET values plus a metadata object
 * to include in list responses.
 */

const DEFAULT_PAGE     = 1;
const DEFAULT_PER_PAGE = 20;
const MAX_PER_PAGE     = 100;

/**
 * @param {import('express').Request} req
 * @returns {{ limit: number, offset: number, page: number, perPage: number }}
 */
function parsePagination(req) {
  const page    = Math.max(1, parseInt(req.query.page, 10)     || DEFAULT_PAGE);
  const perPage = Math.min(
    MAX_PER_PAGE,
    Math.max(1, parseInt(req.query.per_page, 10) || DEFAULT_PER_PAGE)
  );

  return {
    page,
    perPage,
    limit:  perPage,
    offset: (page - 1) * perPage,
  };
}

/**
 * Build the meta object that goes into sendSuccess({ meta }).
 * @param {{ page: number, perPage: number, total: number }} opts
 */
function buildMeta({ page, perPage, total }) {
  return {
    page,
    per_page:    perPage,
    total,
    total_pages: Math.ceil(total / perPage),
  };
}

module.exports = { parsePagination, buildMeta };
