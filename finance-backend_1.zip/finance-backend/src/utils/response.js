/**
 * Response Utilities
 * Centralises the shape of every JSON response so the frontend always gets
 * a predictable envelope:  { success, message, data, meta }
 */

/**
 * Send a successful response.
 * @param {import('express').Response} res
 * @param {object}  payload
 * @param {*}       payload.data
 * @param {string}  [payload.message]
 * @param {object}  [payload.meta]     – pagination, totals, etc.
 * @param {number}  [payload.status]   – HTTP status, defaults 200
 */
function sendSuccess(res, { data = null, message = "OK", meta = null, status = 200 } = {}) {
  const body = { success: true, message, data };
  if (meta) body.meta = meta;
  return res.status(status).json(body);
}

/**
 * Send an error response.
 * @param {import('express').Response} res
 * @param {object} payload
 * @param {string} payload.message
 * @param {number} [payload.status]
 * @param {object} [payload.errors]   – field-level validation detail
 */
function sendError(res, { message = "Something went wrong", status = 500, errors = null } = {}) {
  const body = { success: false, message };
  if (errors) body.errors = errors;
  return res.status(status).json(body);
}

module.exports = { sendSuccess, sendError };
