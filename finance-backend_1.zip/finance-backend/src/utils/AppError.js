/**
 * AppError
 * A structured error class that carries an HTTP status code alongside the
 * message. Throwing AppError anywhere in the app lets the global error handler
 * reply consistently without extra boilerplate in controllers/services.
 */

class AppError extends Error {
  /**
   * @param {string}  message    Human-readable error description.
   * @param {number}  statusCode HTTP status code (4xx / 5xx).
   * @param {object}  [errors]   Optional field-level validation errors.
   */
  constructor(message, statusCode = 500, errors = null) {
    super(message);
    this.statusCode = statusCode;
    this.errors = errors;
    this.isOperational = true; // Distinguish expected errors from bugs
    Error.captureStackTrace(this, this.constructor);
  }
}

module.exports = AppError;
