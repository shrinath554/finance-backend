const dashboardService = require("../services/dashboardService");
const { sendSuccess }    = require("../utils/response");
const AppError           = require("../utils/AppError");

function getSummary(req, res, next) {
  try {
    const { date_from, date_to } = req.query;
    const data = dashboardService.getSummary({ date_from, date_to });
    sendSuccess(res, { data });
  } catch (err) {
    next(err);
  }
}

function getCategoryBreakdown(req, res, next) {
  try {
    const { date_from, date_to } = req.query;
    const data = dashboardService.getCategoryBreakdown({ date_from, date_to });
    sendSuccess(res, { data });
  } catch (err) {
    next(err);
  }
}

function getMonthlyTrends(req, res, next) {
  try {
    const months = parseInt(req.query.months, 10) || 12;
    if (months < 1 || months > 60) {
      throw new AppError("months must be between 1 and 60.", 400);
    }
    const data = dashboardService.getMonthlyTrends(months);
    sendSuccess(res, { data });
  } catch (err) {
    next(err);
  }
}

function getWeeklyTrends(req, res, next) {
  try {
    const weeks = parseInt(req.query.weeks, 10) || 8;
    if (weeks < 1 || weeks > 52) {
      throw new AppError("weeks must be between 1 and 52.", 400);
    }
    const data = dashboardService.getWeeklyTrends(weeks);
    sendSuccess(res, { data });
  } catch (err) {
    next(err);
  }
}

function getRecentActivity(req, res, next) {
  try {
    const limit = Math.min(50, Math.max(1, parseInt(req.query.limit, 10) || 10));
    const data  = dashboardService.getRecentActivity(limit);
    sendSuccess(res, { data });
  } catch (err) {
    next(err);
  }
}

module.exports = { getSummary, getCategoryBreakdown, getMonthlyTrends, getWeeklyTrends, getRecentActivity };
