const recordService  = require("../services/recordService");
const { sendSuccess }  = require("../utils/response");
const { parsePagination, buildMeta } = require("../utils/pagination");

function listRecords(req, res, next) {
  try {
    const pagination           = parsePagination(req);
    const { records, total }   = recordService.listRecords(req.query, pagination);
    sendSuccess(res, {
      data: records,
      meta: buildMeta({ ...pagination, total }),
    });
  } catch (err) {
    next(err);
  }
}

function getRecordById(req, res, next) {
  try {
    const record = recordService.getRecordById(Number(req.params.id));
    sendSuccess(res, { data: record });
  } catch (err) {
    next(err);
  }
}

function createRecord(req, res, next) {
  try {
    const record = recordService.createRecord(req.body, req.user.id);
    sendSuccess(res, { data: record, message: "Record created successfully.", status: 201 });
  } catch (err) {
    next(err);
  }
}

function updateRecord(req, res, next) {
  try {
    const record = recordService.updateRecord(Number(req.params.id), req.body, req.user.id);
    sendSuccess(res, { data: record, message: "Record updated successfully." });
  } catch (err) {
    next(err);
  }
}

function deleteRecord(req, res, next) {
  try {
    recordService.deleteRecord(Number(req.params.id));
    sendSuccess(res, { data: null, message: "Record deleted successfully." });
  } catch (err) {
    next(err);
  }
}

module.exports = { listRecords, getRecordById, createRecord, updateRecord, deleteRecord };
