const authService   = require("../services/authService");
const { sendSuccess } = require("../utils/response");

async function register(req, res, next) {
  try {
    const result = await authService.register(req.body);
    sendSuccess(res, {
      data:    result,
      message: "Account created successfully.",
      status:  201,
    });
  } catch (err) {
    next(err);
  }
}

async function login(req, res, next) {
  try {
    const result = await authService.login(req.body);
    sendSuccess(res, { data: result, message: "Login successful." });
  } catch (err) {
    next(err);
  }
}

function me(req, res) {
  sendSuccess(res, { data: req.user });
}

module.exports = { register, login, me };
