const userService    = require("../services/userService");
const { sendSuccess }  = require("../utils/response");
const { parsePagination, buildMeta } = require("../utils/pagination");

function listUsers(req, res, next) {
  try {
    const pagination         = parsePagination(req);
    const { users, total }   = userService.listUsers(pagination);
    sendSuccess(res, {
      data: users,
      meta: buildMeta({ ...pagination, total }),
    });
  } catch (err) {
    next(err);
  }
}

function getUserById(req, res, next) {
  try {
    const user = userService.getUserById(Number(req.params.id));
    sendSuccess(res, { data: user });
  } catch (err) {
    next(err);
  }
}

async function createUser(req, res, next) {
  try {
    const user = await userService.createUser(req.body);
    sendSuccess(res, { data: user, message: "User created successfully.", status: 201 });
  } catch (err) {
    next(err);
  }
}

async function updateUser(req, res, next) {
  try {
    const user = await userService.updateUser(Number(req.params.id), req.body);
    sendSuccess(res, { data: user, message: "User updated successfully." });
  } catch (err) {
    next(err);
  }
}

function updateUserStatus(req, res, next) {
  try {
    const user = userService.updateUserStatus(
      Number(req.params.id),
      req.body.status,
      req.user.id
    );
    sendSuccess(res, { data: user, message: `User ${req.body.status} successfully.` });
  } catch (err) {
    next(err);
  }
}

function deleteUser(req, res, next) {
  try {
    userService.deleteUser(Number(req.params.id), req.user.id);
    sendSuccess(res, { data: null, message: "User deleted successfully." });
  } catch (err) {
    next(err);
  }
}

module.exports = { listUsers, getUserById, createUser, updateUser, updateUserStatus, deleteUser };
