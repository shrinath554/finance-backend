/**
 * Financial Records Routes
 *
 * GET    /api/records         – List records with filters (viewer, analyst, admin)
 * GET    /api/records/:id     – Get single record       (viewer, analyst, admin)
 * POST   /api/records         – Create record           (analyst, admin)
 * PATCH  /api/records/:id     – Update record           (analyst, admin)
 * DELETE /api/records/:id     – Soft-delete record      (admin)
 *
 * Query params for GET /api/records:
 *   type        income | expense
 *   category    exact match string
 *   date_from   YYYY-MM-DD
 *   date_to     YYYY-MM-DD
 *   search      keyword (searches category + notes)
 *   sort_by     date | amount | category | created_at  (default: date)
 *   sort_order  asc | desc                             (default: desc)
 *   page        integer (default: 1)
 *   per_page    integer max 100 (default: 20)
 */

const router             = require("express").Router();
const recordController   = require("../controllers/recordController");
const { authenticate }   = require("../middleware/auth");
const { authorize }      = require("../middleware/rbac");
const { validate }       = require("../middleware/validate");
const {
  createRecordSchema,
  updateRecordSchema,
  recordQuerySchema,
} = require("../validators/recordValidator");

// All record routes require authentication
router.use(authenticate);

router.get(
  "/",
  authorize("viewer", "analyst", "admin"),
  validate(recordQuerySchema, "query"),
  recordController.listRecords
);

router.get(
  "/:id",
  authorize("viewer", "analyst", "admin"),
  recordController.getRecordById
);

router.post(
  "/",
  authorize("analyst", "admin"),
  validate(createRecordSchema),
  recordController.createRecord
);

router.patch(
  "/:id",
  authorize("analyst", "admin"),
  validate(updateRecordSchema),
  recordController.updateRecord
);

router.delete(
  "/:id",
  authorize("admin"),
  recordController.deleteRecord
);

module.exports = router;
