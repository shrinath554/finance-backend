/**
 * Root Router
 * Mounts all feature routers under their prefixes.
 * app.js imports this single file so it stays clean.
 */

const router = require("express").Router();

router.use("/auth",      require("./auth"));
router.use("/users",     require("./users"));
router.use("/records",   require("./records"));
router.use("/dashboard", require("./dashboard"));

// Health-check – useful for uptime monitors and CI pipelines
router.get("/health", (_req, res) => {
  res.json({
    success: true,
    message: "Finance API is running.",
    timestamp: new Date().toISOString(),
  });
});

module.exports = router;
