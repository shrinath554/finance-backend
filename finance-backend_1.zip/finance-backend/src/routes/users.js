/**
 * User Routes  – all admin-only
 *
 * GET    /api/users           – List all users (paginated)
 * GET    /api/users/:id       – Get single user
 * POST   /api/users           – Create user
 * PATCH  /api/users/:id       – Update name / email / role
 * PATCH  /api/users/:id/status – Activate or deactivate user
 * DELETE /api/users/:id       – Delete user
 */

const router           = require("express").Router();
const userController   = require("../controllers/userController");
const { authenticate } = require("../middleware/auth");
const { authorize }    = require("../middleware/rbac");
const { validate }     = require("../middleware/validate");
const {
  createUserSchema,
  updateUserSchema,
  updateStatusSchema,
} = require("../validators/userValidator");

// All user management endpoints require authentication + admin role
router.use(authenticate, authorize("admin"));

router.get   ("/",           userController.listUsers);
router.get   ("/:id",        userController.getUserById);
router.post  ("/",           validate(createUserSchema),  userController.createUser);
router.patch ("/:id",        validate(updateUserSchema),  userController.updateUser);
router.patch ("/:id/status", validate(updateStatusSchema),userController.updateUserStatus);
router.delete("/:id",        userController.deleteUser);

module.exports = router;
