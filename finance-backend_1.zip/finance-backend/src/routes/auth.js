/**
 * Auth Routes
 *
 * POST   /api/auth/register   – Create account (open; in prod restrict to admin-only)
 * POST   /api/auth/login      – Login and receive JWT
 * GET    /api/auth/me         – Get current authenticated user
 */

const router             = require("express").Router();
const authController     = require("../controllers/authController");
const { authenticate }   = require("../middleware/auth");
const { validate }       = require("../middleware/validate");
const { registerSchema, loginSchema } = require("../validators/authValidator");

router.post("/register", validate(registerSchema), authController.register);
router.post("/login",    validate(loginSchema),    authController.login);
router.get ("/me",       authenticate,             authController.me);

module.exports = router;
