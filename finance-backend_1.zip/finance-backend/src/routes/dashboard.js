/**
 * Dashboard Routes  – available to all authenticated users
 *
 * GET /api/dashboard/summary    – Income, expenses, net balance
 *   ?date_from  YYYY-MM-DD
 *   ?date_to    YYYY-MM-DD
 *
 * GET /api/dashboard/categories – Category-wise breakdown
 *   ?date_from  YYYY-MM-DD
 *   ?date_to    YYYY-MM-DD
 *
 * GET /api/dashboard/trends/monthly – Monthly income vs expense
 *   ?months  integer 1-60 (default 12)
 *
 * GET /api/dashboard/trends/weekly  – Weekly income vs expense
 *   ?weeks   integer 1-52 (default 8)
 *
 * GET /api/dashboard/recent  – Recent activity feed
 *   ?limit   integer 1-50 (default 10)
 */

const router               = require("express").Router();
const dashboardController  = require("../controllers/dashboardController");
const { authenticate }     = require("../middleware/auth");
const { authorize }        = require("../middleware/rbac");

// All dashboard routes: any authenticated role can read
router.use(authenticate, authorize("viewer", "analyst", "admin"));

router.get("/summary",         dashboardController.getSummary);
router.get("/categories",      dashboardController.getCategoryBreakdown);
router.get("/trends/monthly",  dashboardController.getMonthlyTrends);
router.get("/trends/weekly",   dashboardController.getWeeklyTrends);
router.get("/recent",          dashboardController.getRecentActivity);

module.exports = router;
