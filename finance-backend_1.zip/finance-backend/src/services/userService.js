/**
 * User Service
 * All user management operations. Only admins can call these —
 * the route layer enforces RBAC before reaching here.
 */

const bcrypt    = require("bcryptjs");
const { getDb } = require("../config/database");
const AppError  = require("../utils/AppError");

const SAFE_COLS = "id, name, email, role, status, created_at, updated_at";

/**
 * List all users with optional pagination.
 */
function listUsers({ limit, offset }) {
  const db = getDb();

  const total = db.prepare("SELECT COUNT(*) as count FROM users").get().count;
  const users = db.prepare(`
    SELECT ${SAFE_COLS} FROM users
    ORDER BY created_at DESC
    LIMIT ? OFFSET ?
  `).all(limit, offset);

  return { users, total };
}

/**
 * Get a single user by ID.
 */
function getUserById(id) {
  const db   = getDb();
  const user = db.prepare(`SELECT ${SAFE_COLS} FROM users WHERE id = ?`).get(id);

  if (!user) throw new AppError("User not found.", 404);
  return user;
}

/**
 * Create a new user (admin action).
 */
async function createUser(data) {
  const db = getDb();

  const existing = db.prepare("SELECT id FROM users WHERE email = ?").get(data.email);
  if (existing) throw new AppError("An account with that email already exists.", 409);

  const hash   = await bcrypt.hash(data.password, 10);
  const result = db.prepare(`
    INSERT INTO users (name, email, password, role)
    VALUES (@name, @email, @password, @role)
  `).run({ name: data.name, email: data.email, password: hash, role: data.role });

  return db.prepare(`SELECT ${SAFE_COLS} FROM users WHERE id = ?`).get(result.lastInsertRowid);
}

/**
 * Update name / email / role of a user.
 */
async function updateUser(id, data) {
  const db = getDb();

  const user = db.prepare("SELECT id FROM users WHERE id = ?").get(id);
  if (!user) throw new AppError("User not found.", 404);

  // Check email uniqueness if email is being changed
  if (data.email) {
    const collision = db.prepare("SELECT id FROM users WHERE email = ? AND id != ?").get(data.email, id);
    if (collision) throw new AppError("That email is already taken.", 409);
  }

  const fields = [];
  const params = {};

  if (data.name)  { fields.push("name = @name");   params.name  = data.name;  }
  if (data.email) { fields.push("email = @email");  params.email = data.email; }
  if (data.role)  { fields.push("role = @role");    params.role  = data.role;  }

  if (fields.length === 0) throw new AppError("No fields to update.", 400);

  fields.push("updated_at = datetime('now')");
  params.id = id;

  db.prepare(`UPDATE users SET ${fields.join(", ")} WHERE id = @id`).run(params);

  return db.prepare(`SELECT ${SAFE_COLS} FROM users WHERE id = ?`).get(id);
}

/**
 * Activate or deactivate a user account.
 */
function updateUserStatus(id, status, requestingUserId) {
  const db = getDb();

  const user = db.prepare("SELECT id FROM users WHERE id = ?").get(id);
  if (!user) throw new AppError("User not found.", 404);

  // Prevent admins from locking themselves out
  if (id === requestingUserId && status === "inactive") {
    throw new AppError("You cannot deactivate your own account.", 400);
  }

  db.prepare(`
    UPDATE users SET status = ?, updated_at = datetime('now') WHERE id = ?
  `).run(status, id);

  return db.prepare(`SELECT ${SAFE_COLS} FROM users WHERE id = ?`).get(id);
}

/**
 * Hard-delete a user. Analysts/viewers get a nicer message if this is
 * called — the route already restricts it to admins.
 */
function deleteUser(id, requestingUserId) {
  const db = getDb();

  if (id === requestingUserId) {
    throw new AppError("You cannot delete your own account.", 400);
  }

  const user = db.prepare("SELECT id FROM users WHERE id = ?").get(id);
  if (!user) throw new AppError("User not found.", 404);

  db.prepare("DELETE FROM users WHERE id = ?").run(id);
  return { deleted: true };
}

module.exports = { listUsers, getUserById, createUser, updateUser, updateUserStatus, deleteUser };
