/**
 * Auth Service
 * Handles user registration, login, and JWT generation.
 * No Express objects here — pure business logic.
 */

const bcrypt          = require("bcryptjs");
const jwt             = require("jsonwebtoken");
const { getDb }       = require("../config/database");
const AppError        = require("../utils/AppError");
const { JWT_SECRET }  = require("../middleware/auth");

const SALT_ROUNDS    = 10;
const TOKEN_EXPIRES  = "8h";

/**
 * Register a new user.
 * @param {{ name, email, password, role }} data
 * @returns {{ user, token }}
 */
async function register(data) {
  const db = getDb();

  const existing = db.prepare("SELECT id FROM users WHERE email = ?").get(data.email);
  if (existing) {
    throw new AppError("An account with that email already exists.", 409);
  }

  const hash = await bcrypt.hash(data.password, SALT_ROUNDS);

  const result = db.prepare(`
    INSERT INTO users (name, email, password, role)
    VALUES (@name, @email, @password, @role)
  `).run({ name: data.name, email: data.email, password: hash, role: data.role });

  const user  = db.prepare("SELECT id, name, email, role, status, created_at FROM users WHERE id = ?")
                  .get(result.lastInsertRowid);

  const token = generateToken(user);
  return { user, token };
}

/**
 * Authenticate with email + password.
 * @param {{ email, password }} credentials
 * @returns {{ user, token }}
 */
async function login({ email, password }) {
  const db = getDb();

  const user = db.prepare("SELECT * FROM users WHERE email = ?").get(email);

  // Use constant-time comparison even if user is not found (prevent timing attacks)
  const passwordHash  = user ? user.password : "$2a$10$invalid.hash.to.prevent.timing";
  const isMatch       = await bcrypt.compare(password, passwordHash);

  if (!user || !isMatch) {
    throw new AppError("Invalid email or password.", 401);
  }
  if (user.status === "inactive") {
    throw new AppError("Your account has been deactivated.", 403);
  }

  const { password: _pwd, ...safeUser } = user;
  const token = generateToken(safeUser);
  return { user: safeUser, token };
}

function generateToken(user) {
  return jwt.sign(
    { id: user.id, email: user.email, role: user.role },
    JWT_SECRET,
    { expiresIn: TOKEN_EXPIRES }
  );
}

module.exports = { register, login };
