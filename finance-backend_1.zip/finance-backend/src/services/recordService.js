/**
 * Financial Records Service
 * Core business logic for financial entry management.
 * Supports filtering, full-text search across category/notes, and pagination.
 */

const { getDb } = require("../config/database");
const AppError  = require("../utils/AppError");

/**
 * List records with filters, search, sorting, and pagination.
 *
 * @param {object} filters   – parsed from query string by the validator
 * @param {object} pagination – { limit, offset, page, perPage }
 * @returns {{ records, total }}
 */
function listRecords(filters, pagination) {
  const db = getDb();

  const conditions = ["r.is_deleted = 0"];
  const params     = [];

  if (filters.type) {
    conditions.push("r.type = ?");
    params.push(filters.type);
  }
  if (filters.category) {
    conditions.push("r.category = ?");
    params.push(filters.category);
  }
  if (filters.date_from) {
    conditions.push("r.date >= ?");
    params.push(filters.date_from);
  }
  if (filters.date_to) {
    conditions.push("r.date <= ?");
    params.push(filters.date_to);
  }
  if (filters.search) {
    // Simple full-text search across category and notes
    conditions.push("(r.category LIKE ? OR r.notes LIKE ?)");
    const term = `%${filters.search}%`;
    params.push(term, term);
  }

  const where = conditions.join(" AND ");

  // Allowlist sort columns to prevent SQL injection
  const SORTABLE = { date: "r.date", amount: "r.amount", category: "r.category", created_at: "r.created_at" };
  const sortCol  = SORTABLE[filters.sort_by]  || "r.date";
  const sortDir  = filters.sort_order === "asc" ? "ASC" : "DESC";

  const baseQuery = `
    FROM financial_records r
    JOIN users created_by_user ON r.created_by = created_by_user.id
    WHERE ${where}
  `;

  const total = db.prepare(`SELECT COUNT(*) as count ${baseQuery}`).get(...params).count;

  const records = db.prepare(`
    SELECT
      r.id, r.amount, r.type, r.category, r.date, r.notes,
      r.created_at, r.updated_at,
      json_object('id', created_by_user.id, 'name', created_by_user.name) AS created_by
    ${baseQuery}
    ORDER BY ${sortCol} ${sortDir}
    LIMIT ? OFFSET ?
  `).all(...params, pagination.limit, pagination.offset);

  // Parse the JSON string SQLite returns for the created_by object
  const parsed = records.map((r) => ({
    ...r,
    created_by: JSON.parse(r.created_by),
  }));

  return { records: parsed, total };
}

/**
 * Get a single record by ID (non-deleted).
 */
function getRecordById(id) {
  const db     = getDb();
  const record = db.prepare(`
    SELECT
      r.id, r.amount, r.type, r.category, r.date, r.notes,
      r.created_at, r.updated_at,
      json_object('id', u.id, 'name', u.name) AS created_by
    FROM financial_records r
    JOIN users u ON r.created_by = u.id
    WHERE r.id = ? AND r.is_deleted = 0
  `).get(id);

  if (!record) throw new AppError("Financial record not found.", 404);
  return { ...record, created_by: JSON.parse(record.created_by) };
}

/**
 * Create a new financial record.
 */
function createRecord(data, userId) {
  const db     = getDb();
  const result = db.prepare(`
    INSERT INTO financial_records (amount, type, category, date, notes, created_by)
    VALUES (@amount, @type, @category, @date, @notes, @created_by)
  `).run({ ...data, notes: data.notes ?? null, created_by: userId });

  return getRecordById(result.lastInsertRowid);
}

/**
 * Partially update a financial record.
 * Only the record's creator or an admin should reach this — the route
 * layer handles that restriction at the RBAC level.
 */
function updateRecord(id, data, userId) {
  const db = getDb();

  const existing = db.prepare("SELECT id FROM financial_records WHERE id = ? AND is_deleted = 0").get(id);
  if (!existing) throw new AppError("Financial record not found.", 404);

  const fields = [];
  const params = {};

  const allowed = ["amount", "type", "category", "date", "notes"];
  for (const key of allowed) {
    if (data[key] !== undefined) {
      fields.push(`${key} = @${key}`);
      params[key] = data[key];
    }
  }

  if (fields.length === 0) throw new AppError("No valid fields provided.", 400);

  fields.push("updated_by = @updated_by", "updated_at = datetime('now')");
  params.updated_by = userId;
  params.id         = id;

  db.prepare(`UPDATE financial_records SET ${fields.join(", ")} WHERE id = @id`).run(params);

  return getRecordById(id);
}

/**
 * Soft-delete a financial record.
 */
function deleteRecord(id) {
  const db = getDb();

  const existing = db.prepare("SELECT id FROM financial_records WHERE id = ? AND is_deleted = 0").get(id);
  if (!existing) throw new AppError("Financial record not found.", 404);

  db.prepare(`
    UPDATE financial_records
    SET is_deleted = 1, updated_at = datetime('now')
    WHERE id = ?
  `).run(id);

  return { deleted: true };
}

module.exports = { listRecords, getRecordById, createRecord, updateRecord, deleteRecord };
