/**
 * Dashboard Service
 * Aggregated analytics queries for the finance dashboard.
 * All queries exclude soft-deleted records.
 *
 * Design note: these are read-only, denormalized aggregation queries.
 * In a production system with heavy load you'd add a caching layer (Redis)
 * in front of these, but for this scope SQLite handles it fine.
 */

const { getDb } = require("../config/database");

/**
 * High-level financial summary.
 * Returns total income, total expenses, net balance, and record count.
 */
function getSummary(filters = {}) {
  const db = getDb();

  const { whereClause, params } = buildDateFilter(filters);

  const row = db.prepare(`
    SELECT
      COALESCE(SUM(CASE WHEN type = 'income'  THEN amount ELSE 0 END), 0) AS total_income,
      COALESCE(SUM(CASE WHEN type = 'expense' THEN amount ELSE 0 END), 0) AS total_expenses,
      COUNT(*) AS record_count
    FROM financial_records
    WHERE is_deleted = 0 ${whereClause}
  `).get(...params);

  return {
    total_income:    round(row.total_income),
    total_expenses:  round(row.total_expenses),
    net_balance:     round(row.total_income - row.total_expenses),
    record_count:    row.record_count,
  };
}

/**
 * Category-wise income and expense totals.
 */
function getCategoryBreakdown(filters = {}) {
  const db = getDb();
  const { whereClause, params } = buildDateFilter(filters);

  const rows = db.prepare(`
    SELECT
      category,
      type,
      ROUND(SUM(amount), 2) AS total,
      COUNT(*) AS count
    FROM financial_records
    WHERE is_deleted = 0 ${whereClause}
    GROUP BY category, type
    ORDER BY total DESC
  `).all(...params);

  // Reshape into { category -> { income, expense, net } }
  const map = {};
  for (const row of rows) {
    if (!map[row.category]) {
      map[row.category] = { category: row.category, income: 0, expense: 0, count: 0 };
    }
    map[row.category][row.type] += row.total;
    map[row.category].count     += row.count;
  }

  const categories = Object.values(map).map((c) => ({
    ...c,
    net: round(c.income - c.expense),
  }));

  return categories;
}

/**
 * Monthly income vs expense trends.
 * Returns the last N months (default 12).
 */
function getMonthlyTrends(months = 12) {
  const db = getDb();

  const rows = db.prepare(`
    SELECT
      strftime('%Y-%m', date) AS month,
      ROUND(SUM(CASE WHEN type = 'income'  THEN amount ELSE 0 END), 2) AS income,
      ROUND(SUM(CASE WHEN type = 'expense' THEN amount ELSE 0 END), 2) AS expense
    FROM financial_records
    WHERE is_deleted = 0
      AND date >= date('now', ? || ' months')
    GROUP BY month
    ORDER BY month ASC
  `).all(`-${months}`);

  return rows.map((r) => ({
    ...r,
    net: round(r.income - r.expense),
  }));
}

/**
 * Weekly income vs expense trends.
 * Returns the last N weeks (default 8).
 */
function getWeeklyTrends(weeks = 8) {
  const db = getDb();

  const rows = db.prepare(`
    SELECT
      strftime('%Y-W%W', date) AS week,
      ROUND(SUM(CASE WHEN type = 'income'  THEN amount ELSE 0 END), 2) AS income,
      ROUND(SUM(CASE WHEN type = 'expense' THEN amount ELSE 0 END), 2) AS expense
    FROM financial_records
    WHERE is_deleted = 0
      AND date >= date('now', ? || ' days')
    GROUP BY week
    ORDER BY week ASC
  `).all(`-${weeks * 7}`);

  return rows.map((r) => ({
    ...r,
    net: round(r.income - r.expense),
  }));
}

/**
 * Most recent N financial records (for a dashboard activity feed).
 */
function getRecentActivity(limit = 10) {
  const db = getDb();

  const rows = db.prepare(`
    SELECT
      r.id, r.amount, r.type, r.category, r.date, r.notes, r.created_at,
      u.name AS created_by_name
    FROM financial_records r
    JOIN users u ON r.created_by = u.id
    WHERE r.is_deleted = 0
    ORDER BY r.created_at DESC
    LIMIT ?
  `).all(limit);

  return rows;
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function buildDateFilter({ date_from, date_to } = {}) {
  const conditions = [];
  const params     = [];

  if (date_from) { conditions.push("AND date >= ?"); params.push(date_from); }
  if (date_to)   { conditions.push("AND date <= ?"); params.push(date_to);   }

  return { whereClause: conditions.join(" "), params };
}

function round(n) {
  return Math.round((n + Number.EPSILON) * 100) / 100;
}

module.exports = { getSummary, getCategoryBreakdown, getMonthlyTrends, getWeeklyTrends, getRecentActivity };
