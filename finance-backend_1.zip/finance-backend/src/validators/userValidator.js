const { z } = require("zod");

const createUserSchema = z.object({
  name:     z.string().min(2).max(100),
  email:    z.string().email(),
  password: z
    .string()
    .min(8)
    .regex(/[A-Z]/,  "Must contain an uppercase letter.")
    .regex(/[0-9]/,  "Must contain a number.")
    .regex(/[^A-Za-z0-9]/, "Must contain a special character."),
  role: z.enum(["viewer", "analyst", "admin"]).default("viewer"),
});

const updateUserSchema = z.object({
  name:   z.string().min(2).max(100).optional(),
  email:  z.string().email().optional(),
  role:   z.enum(["viewer", "analyst", "admin"]).optional(),
}).refine((data) => Object.keys(data).length > 0, {
  message: "At least one field must be provided.",
});

const updateStatusSchema = z.object({
  status: z.enum(["active", "inactive"]),
});

module.exports = { createUserSchema, updateUserSchema, updateStatusSchema };
