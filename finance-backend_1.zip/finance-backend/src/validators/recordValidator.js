const { z } = require("zod");

const ISO_DATE = /^\d{4}-\d{2}-\d{2}$/;

const createRecordSchema = z.object({
  amount:   z.number({ invalid_type_error: "Amount must be a number." })
              .positive("Amount must be a positive number."),
  type:     z.enum(["income", "expense"], {
              errorMap: () => ({ message: "Type must be 'income' or 'expense'." }),
            }),
  category: z.string().min(1, "Category is required.").max(80),
  date:     z.string()
              .regex(ISO_DATE, "Date must be in YYYY-MM-DD format.")
              .refine((d) => !isNaN(Date.parse(d)), "Date is not valid."),
  notes:    z.string().max(500).optional().nullable(),
});

const updateRecordSchema = createRecordSchema.partial().refine(
  (data) => Object.keys(data).length > 0,
  { message: "At least one field must be provided." }
);

const recordQuerySchema = z.object({
  type:       z.enum(["income", "expense"]).optional(),
  category:   z.string().optional(),
  date_from:  z.string().regex(ISO_DATE).optional(),
  date_to:    z.string().regex(ISO_DATE).optional(),
  page:       z.coerce.number().int().positive().optional(),
  per_page:   z.coerce.number().int().positive().max(100).optional(),
  sort_by:    z.enum(["date", "amount", "category", "created_at"]).optional().default("date"),
  sort_order: z.enum(["asc", "desc"]).optional().default("desc"),
  search:     z.string().max(100).optional(),
});

module.exports = { createRecordSchema, updateRecordSchema, recordQuerySchema };
