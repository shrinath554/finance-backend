/**
 * Authentication Middleware
 * Verifies the Bearer JWT and attaches the decoded user payload to req.user.
 * Any route that needs authentication should use this middleware first.
 */

const jwt       = require("jsonwebtoken");
const AppError  = require("../utils/AppError");
const { getDb } = require("../config/database");

const JWT_SECRET = process.env.JWT_SECRET || "finance_jwt_secret_change_in_production";

/**
 * authenticate
 * Reads Authorization header, verifies the JWT, and loads the live user row
 * from the DB to ensure inactive / deleted accounts are rejected.
 */
async function authenticate(req, _res, next) {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      throw new AppError("Authentication required. Provide a Bearer token.", 401);
    }

    const token = authHeader.split(" ")[1];

    let decoded;
    try {
      decoded = jwt.verify(token, JWT_SECRET);
    } catch (err) {
      if (err.name === "TokenExpiredError") {
        throw new AppError("Token has expired. Please log in again.", 401);
      }
      throw new AppError("Invalid token.", 401);
    }

    // Always fetch from DB so status changes are immediately reflected
    const db   = getDb();
    const user = db.prepare("SELECT id, name, email, role, status FROM users WHERE id = ?").get(decoded.id);

    if (!user) {
      throw new AppError("User no longer exists.", 401);
    }
    if (user.status === "inactive") {
      throw new AppError("Your account has been deactivated.", 403);
    }

    req.user = user;
    next();
  } catch (err) {
    next(err);
  }
}

module.exports = { authenticate, JWT_SECRET };
