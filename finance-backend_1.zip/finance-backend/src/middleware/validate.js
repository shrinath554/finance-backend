/**
 * Validation Middleware Factory
 * Returns an Express middleware that validates req.body / req.query / req.params
 * against a Zod schema. Errors are forwarded to the global error handler.
 *
 * Usage:
 *   router.post("/login", validate(loginSchema), authController.login)
 */

function validate(schema, target = "body") {
  return (req, _res, next) => {
    try {
      const parsed = schema.parse(req[target]);
      req[target]  = parsed; // Replace with the coerced/parsed values
      next();
    } catch (err) {
      next(err); // Zod errors are handled in errorHandler.js
    }
  };
}

module.exports = { validate };
