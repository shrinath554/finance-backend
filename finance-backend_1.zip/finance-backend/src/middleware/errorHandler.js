/**
 * Global Error Handler
 * Express's 4-argument middleware signature is required for error handling.
 * All errors thrown anywhere in the app bubble here — no try/catch needed
 * in individual routes once you call next(err).
 */

const { sendError } = require("../utils/response");

// eslint-disable-next-line no-unused-vars
function errorHandler(err, req, res, next) {
  // Zod validation errors come pre-formatted from the validate middleware
  if (err.name === "ZodError") {
    const errors = err.errors.reduce((acc, e) => {
      const key = e.path.join(".");
      acc[key] = e.message;
      return acc;
    }, {});
    return sendError(res, { message: "Validation failed.", status: 422, errors });
  }

  // SQLite unique constraint violation
  if (err.code === "SQLITE_CONSTRAINT_UNIQUE") {
    return sendError(res, {
      message: "A record with that value already exists.",
      status: 409,
    });
  }

  // Our own structured errors
  if (err.isOperational) {
    return sendError(res, {
      message: err.message,
      status:  err.statusCode,
      errors:  err.errors,
    });
  }

  // Unexpected / programming errors — log and return generic message
  console.error("[Unhandled Error]", err);
  return sendError(res, { message: "An unexpected error occurred.", status: 500 });
}

module.exports = { errorHandler };
