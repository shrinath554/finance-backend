/**
 * Role-Based Access Control (RBAC) Middleware
 *
 * Role hierarchy (ascending privilege):
 *   viewer  < analyst < admin
 *
 * Usage in routes:
 *   router.post("/records", authenticate, authorize("analyst", "admin"), createRecord)
 *   router.delete("/records/:id", authenticate, authorize("admin"), deleteRecord)
 *
 * Design note: roles are passed as explicit allowlists rather than a numeric
 * hierarchy so that future roles can be added without touching existing guards.
 */

const AppError = require("../utils/AppError");

/**
 * ROLE_PERMISSIONS maps every role to its allowed action categories.
 * This is the single source of truth — middleware and documentation both
 * reference it instead of duplicating role logic.
 */
const ROLE_PERMISSIONS = {
  viewer: {
    records:   ["read"],
    dashboard: ["read"],
    users:     [],
  },
  analyst: {
    records:   ["read", "create", "update"],
    dashboard: ["read"],
    users:     [],
  },
  admin: {
    records:   ["read", "create", "update", "delete"],
    dashboard: ["read"],
    users:     ["read", "create", "update", "delete"],
  },
};

/**
 * authorize(...allowedRoles)
 * Returns middleware that passes only if req.user.role is in the allowlist.
 * Must be used AFTER the authenticate middleware.
 *
 * @param {...string} allowedRoles  One or more role names.
 */
function authorize(...allowedRoles) {
  return (req, _res, next) => {
    if (!req.user) {
      return next(new AppError("Authentication required.", 401));
    }

    if (!allowedRoles.includes(req.user.role)) {
      return next(
        new AppError(
          `Access denied. Required role: ${allowedRoles.join(" or ")}. Your role: ${req.user.role}.`,
          403
        )
      );
    }

    next();
  };
}

module.exports = { authorize, ROLE_PERMISSIONS };
